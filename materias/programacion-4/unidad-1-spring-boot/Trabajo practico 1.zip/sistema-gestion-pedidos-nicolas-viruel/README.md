# Trabajo Práctico: Fundamentos de Spring

**Alumno:** Nicolas Viruel

## Objetivo

Sistema de Gestión de Pedidos desarrollado con Spring Boot para aplicar Application Context, beans, inyección de dependencias por constructor y estereotipos de Spring.

## Dependencias

- Spring Web
- Spring Data JPA
- Lombok
- H2 Database
- Spring Boot DevTools
- Spring Boot Test

## Estructura

- `entity`: entidades JPA del UML.
- `dto`: DTOs de creación, edición y respuesta.
- `repository`: acceso a datos con `@Repository`.
- `service`: lógica de negocio con `@Service` e inyección por constructor.
- `mapper`: conversión entre entidades y DTOs con `@Component`.
- `controller`: endpoints REST para consultar los datos cargados.
- `config`: inicialización de datos a partir de DTOs.

## Datos iniciales

Al iniciar la aplicación se crean:

- 2 usuarios.
- 3 pedidos, todos con al menos 2 detalles.
- 3 categorías.
- 10 productos.

## Ejecución

```bash
mvn spring-boot:run
```

La aplicación se ejecuta en `http://localhost:8080`.

## Endpoints de verificación

- `GET /api/usuarios`
- `GET /api/pedidos`
- `GET /api/categorias`
- `GET /api/productos`
- Consola H2: `/h2-console`

Credenciales H2:

- JDBC URL: `jdbc:h2:mem:pedidosdb`
- Usuario: `sa`
- Contraseña: vacía

## Pruebas

```bash
mvn test
```

La prueba automática verifica las cantidades pedidas y que cada pedido tenga al menos dos detalles.
