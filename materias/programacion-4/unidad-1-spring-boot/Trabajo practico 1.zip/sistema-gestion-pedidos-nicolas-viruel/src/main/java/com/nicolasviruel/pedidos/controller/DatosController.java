package com.nicolasviruel.pedidos.controller;
import com.nicolasviruel.pedidos.dto.categoria.CategoriaDto;
import com.nicolasviruel.pedidos.dto.pedido.PedidoDto;
import com.nicolasviruel.pedidos.dto.producto.ProductoDto;
import com.nicolasviruel.pedidos.dto.usuario.UsuarioDto;
import com.nicolasviruel.pedidos.service.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api")
public class DatosController {
    private final CategoriaService categoriaService;
    private final ProductoService productoService;
    private final UsuarioService usuarioService;
    private final PedidoService pedidoService;
    public DatosController(CategoriaService categoriaService, ProductoService productoService,
                           UsuarioService usuarioService, PedidoService pedidoService) {
        this.categoriaService = categoriaService; this.productoService = productoService;
        this.usuarioService = usuarioService; this.pedidoService = pedidoService;
    }
    @GetMapping("/categorias") public List<CategoriaDto> categorias() { return categoriaService.listar(); }
    @GetMapping("/productos") public List<ProductoDto> productos() { return productoService.listar(); }
    @GetMapping("/usuarios") public List<UsuarioDto> usuarios() { return usuarioService.listar(); }
    @GetMapping("/pedidos") public List<PedidoDto> pedidos() { return pedidoService.listar(); }
}
