package com.nicolasviruel.pedidos.dto.producto;
public record ProductoCreate(String nombre, Double precio, String descripcion, Integer stock, String imagen, Boolean disponible, Long categoriaId) {}
