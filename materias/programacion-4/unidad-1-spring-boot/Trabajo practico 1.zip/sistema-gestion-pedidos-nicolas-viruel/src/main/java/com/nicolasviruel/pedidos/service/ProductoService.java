package com.nicolasviruel.pedidos.service;
import com.nicolasviruel.pedidos.dto.producto.*;
import com.nicolasviruel.pedidos.entity.Categoria;
import com.nicolasviruel.pedidos.entity.Producto;
import com.nicolasviruel.pedidos.mapper.DtoMapper;
import com.nicolasviruel.pedidos.repository.CategoriaRepository;
import com.nicolasviruel.pedidos.repository.ProductoRepository;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class ProductoService {
    private final ProductoRepository repository;
    private final CategoriaRepository categoriaRepository;
    private final DtoMapper mapper;
    public ProductoService(ProductoRepository repository, CategoriaRepository categoriaRepository, DtoMapper mapper) {
        this.repository = repository; this.categoriaRepository = categoriaRepository; this.mapper = mapper;
    }
    public ProductoDto crear(ProductoCreate dto) {
        Categoria categoria = categoriaRepository.findById(dto.categoriaId()).orElseThrow(() -> new IllegalArgumentException("Categoría inexistente"));
        Producto entity = Producto.builder().nombre(dto.nombre()).precio(dto.precio()).descripcion(dto.descripcion())
                .stock(dto.stock()).imagen(dto.imagen()).disponible(dto.disponible()).categoria(categoria).build();
        return mapper.toDto(repository.save(entity));
    }
    public List<ProductoDto> listar() { return repository.findAll().stream().map(mapper::toDto).toList(); }
}
