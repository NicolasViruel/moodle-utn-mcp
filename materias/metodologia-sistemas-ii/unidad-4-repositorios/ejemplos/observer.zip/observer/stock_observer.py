"""
Patrón Observer — Sistema de inventario
========================================
Problema resuelto: el InventoryManager ya no conoce por nombre a ningún
servicio concreto. Solo mantiene una lista de objetos que implementan
StockObserver y los notifica cuando el stock baja de umbral.
"""

from abc import ABC, abstractmethod


# ─────────────────────────────────────────────────────────────────────────────
# INTERFAZ — contrato que todo observador debe cumplir
# ─────────────────────────────────────────────────────────────────────────────

class StockObserver(ABC):
    @abstractmethod
    def on_low_stock(self, product_id: str, quantity: int) -> None:
        """Se llama cuando el stock de product_id cae por debajo del umbral."""
        pass


# ─────────────────────────────────────────────────────────────────────────────
# OBSERVADORES CONCRETOS
# ─────────────────────────────────────────────────────────────────────────────

class EmailAlertObserver(StockObserver):
    def on_low_stock(self, product_id: str, quantity: int) -> None:
        print(f"[EMAIL] Alerta enviada: stock bajo en '{product_id}' ({quantity} unidades)")


class AnalyticsObserver(StockObserver):
    def on_low_stock(self, product_id: str, quantity: int) -> None:
        print(f"[ANALYTICS] Evento registrado: low_stock | product={product_id} | qty={quantity}")


class ReplenishObserver(StockObserver):
    def on_low_stock(self, product_id: str, quantity: int) -> None:
        print(f"[REPOSICIÓN] Orden creada: 100 unidades de '{product_id}'")


class PushNotificationObserver(StockObserver):
    """Observador nuevo — no tocamos nada del InventoryManager para agregarlo."""
    def on_low_stock(self, product_id: str, quantity: int) -> None:
        print(f"[PUSH] Notificación enviada al dispositivo: stock crítico en '{product_id}'")


# ─────────────────────────────────────────────────────────────────────────────
# SUJETO — InventoryManager ya no sabe quiénes lo escuchan
# ─────────────────────────────────────────────────────────────────────────────

class InventoryManager:
    LOW_STOCK_THRESHOLD = 10

    def __init__(self):
        self._stock: dict[str, int] = {}
        self._observers: list[StockObserver] = []

    # ── gestión de observadores ──────────────────────────────────────────────

    def subscribe(self, observer: StockObserver) -> None:
        self._observers.append(observer)

    def unsubscribe(self, observer: StockObserver) -> None:
        self._observers.remove(observer)

    # ── notificación interna ─────────────────────────────────────────────────

    def _notify(self, product_id: str, quantity: int) -> None:
        """
        Recorre la lista y avisa a cada observer.
        El try/except está DENTRO del loop: si uno falla, los demás siguen.
        """
        for observer in self._observers:
            try:
                observer.on_low_stock(product_id, quantity)
            except Exception as e:
                print(f"[ERROR] Observer {observer.__class__.__name__} falló: {e}")

    # ── operaciones de inventario ────────────────────────────────────────────

    def update_stock(self, product_id: str, quantity: int) -> None:
        self._stock[product_id] = quantity
        print(f"\n  Stock actualizado: '{product_id}' → {quantity} unidades")
        if quantity < self.LOW_STOCK_THRESHOLD:
            self._notify(product_id, quantity)

    def sell_product(self, product_id: str, sold: int) -> None:
        if product_id not in self._stock:
            raise ValueError(f"Producto '{product_id}' no existe en inventario")
        self._stock[product_id] -= sold
        new_qty = self._stock[product_id]
        print(f"\n  Venta registrada: {sold} ud. de '{product_id}' → quedan {new_qty}")
        if new_qty < self.LOW_STOCK_THRESHOLD:
            self._notify(product_id, new_qty)

    def get_stock(self, product_id: str) -> int:
        return self._stock.get(product_id, 0)
