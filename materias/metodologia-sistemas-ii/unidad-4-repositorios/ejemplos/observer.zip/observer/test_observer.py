"""
Tests del patrón Observer
=========================
Cubre:
  1. Notificación normal a múltiples observers
  2. Suscribir y desuscribir en runtime
  3. Observer que falla NO detiene a los demás (restricción del enunciado)
  4. Agregar un observer nuevo sin tocar InventoryManager
"""

from stock_observer import (
    InventoryManager,
    EmailAlertObserver,
    AnalyticsObserver,
    ReplenishObserver,
    PushNotificationObserver,
    StockObserver,
)


# ─────────────────────────────────────────────────────────────────────────────
# Observer roto — simula un error de red
# ─────────────────────────────────────────────────────────────────────────────

class BrokenObserver(StockObserver):
    def on_low_stock(self, product_id: str, quantity: int) -> None:
        raise ConnectionError("Timeout de red simulado")


# ─────────────────────────────────────────────────────────────────────────────
# TEST 1 — notificación básica a múltiples observers
# ─────────────────────────────────────────────────────────────────────────────

def test_notificacion_multiple():
    print("=" * 60)
    print("TEST 1 — Notificación a múltiples observers")
    print("=" * 60)

    manager = InventoryManager()
    manager.subscribe(EmailAlertObserver())
    manager.subscribe(AnalyticsObserver())
    manager.subscribe(ReplenishObserver())

    # Stock alto → no dispara nada
    manager.update_stock("PROD-001", 50)
    print("  (sin notificaciones, stock alto)\n")

    # Stock bajo → dispara los tres observers
    manager.update_stock("PROD-001", 5)
    print()


# ─────────────────────────────────────────────────────────────────────────────
# TEST 2 — suscribir y desuscribir en runtime
# ─────────────────────────────────────────────────────────────────────────────

def test_suscripcion_dinamica():
    print("=" * 60)
    print("TEST 2 — Suscribir y desuscribir en runtime")
    print("=" * 60)

    manager = InventoryManager()
    analytics = AnalyticsObserver()

    manager.subscribe(EmailAlertObserver())
    manager.subscribe(analytics)
    manager.update_stock("PROD-002", 3)

    print("\n  --- Desuscribimos AnalyticsObserver ---")
    manager.unsubscribe(analytics)
    manager.update_stock("PROD-002", 2)
    print("  (analytics ya no recibe notificaciones)\n")


# ─────────────────────────────────────────────────────────────────────────────
# TEST 3 — observer roto no detiene la cadena
# ─────────────────────────────────────────────────────────────────────────────

def test_observer_roto_no_detiene_cadena():
    print("=" * 60)
    print("TEST 3 — Observer roto NO detiene a los demás")
    print("=" * 60)

    manager = InventoryManager()
    manager.subscribe(EmailAlertObserver())    # 1er observer — debe ejecutarse
    manager.subscribe(BrokenObserver())        # 2do — falla con excepción
    manager.subscribe(ReplenishObserver())     # 3er observer — debe ejecutarse igual

    manager.update_stock("PROD-003", 7)

    print()
    print("  ✓ EmailAlertObserver ejecutó antes del error")
    print("  ✓ BrokenObserver lanzó excepción — fue capturada y registrada")
    print("  ✓ ReplenishObserver ejecutó después del error")
    print()


# ─────────────────────────────────────────────────────────────────────────────
# TEST 4 — agregar PushNotificationObserver sin tocar InventoryManager
# ─────────────────────────────────────────────────────────────────────────────

def test_nuevo_observer_sin_cambiar_manager():
    print("=" * 60)
    print("TEST 4 — Nuevo observer (Push) sin tocar InventoryManager")
    print("=" * 60)

    manager = InventoryManager()
    manager.subscribe(EmailAlertObserver())
    manager.subscribe(PushNotificationObserver())   # nuevo — cero cambios en manager

    manager.sell_product.__doc__  # solo para que no marque como no usado
    manager.update_stock("PROD-004", 20)
    manager.update_stock("PROD-004", 4)
    print()


# ─────────────────────────────────────────────────────────────────────────────
# Ejecutar todos los tests
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    test_notificacion_multiple()
    test_suscripcion_dinamica()
    test_observer_roto_no_detiene_cadena()
    test_nuevo_observer_sin_cambiar_manager()
    print("Todos los tests completados.")
