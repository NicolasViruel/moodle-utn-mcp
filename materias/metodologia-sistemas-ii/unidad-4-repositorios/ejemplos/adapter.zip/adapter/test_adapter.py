"""
Tests del patrón Adapter
=========================
Cubre:
  1. El sistema (cliente) usa GeoServiceAdapter exactamente igual que OldGeoService
  2. La respuesta tiene el formato que el sistema espera
  3. El código cliente no sabe que cambió el proveedor
  4. Extensibilidad: qué pasaría con un tercer proveedor
"""

from geo_adapter import GeoServiceAdapter, OldGeoService


# ─────────────────────────────────────────────────────────────────────────────
# Simulación del código cliente — así están los 40 archivos del sistema
# No saben nada de NewGeoProvider ni de GeoServiceAdapter.
# ─────────────────────────────────────────────────────────────────────────────

def mostrar_info_ip(geo: OldGeoService, ip: str) -> None:
    """
    Esta función representa el código cliente que ya existe en el sistema.
    Recibe cualquier OldGeoService — no sabe si es el real o el adapter.
    """
    data = geo.get_location(ip)
    print(f"  IP       : {ip}")
    print(f"  Ciudad   : {data['city']}")
    print(f"  País     : {data['country']}")
    print(f"  Lat/Lng  : {data['lat']}, {data['lng']}")


# ─────────────────────────────────────────────────────────────────────────────
# TEST 1 — el sistema usa el Adapter sin saber qué hay adentro
# ─────────────────────────────────────────────────────────────────────────────

def test_cliente_no_nota_el_cambio():
    print("=" * 60)
    print("TEST 1 — El cliente usa el Adapter igual que OldGeoService")
    print("=" * 60)

    # Único cambio en toda la app: esta línea de instanciación
    geo = GeoServiceAdapter()

    print("\n  Consulta 1:")
    mostrar_info_ip(geo, "200.45.123.10")

    print("\n  Consulta 2:")
    mostrar_info_ip(geo, "8.8.8.8")
    print()


# ─────────────────────────────────────────────────────────────────────────────
# TEST 2 — el Adapter hereda de OldGeoService (type-check)
# ─────────────────────────────────────────────────────────────────────────────

def test_adapter_es_old_geo_service():
    print("=" * 60)
    print("TEST 2 — GeoServiceAdapter es un OldGeoService (herencia)")
    print("=" * 60)

    geo = GeoServiceAdapter()
    assert isinstance(geo, OldGeoService), "El Adapter debe heredar de OldGeoService"
    print("\n  ✓ isinstance(GeoServiceAdapter(), OldGeoService) → True")
    print("  El sistema de tipos acepta el Adapter donde espera OldGeoService.\n")


# ─────────────────────────────────────────────────────────────────────────────
# TEST 3 — la respuesta tiene exactamente las claves que el sistema espera
# ─────────────────────────────────────────────────────────────────────────────

def test_formato_respuesta_correcto():
    print("=" * 60)
    print("TEST 3 — La respuesta tiene el formato que espera el sistema")
    print("=" * 60)

    geo = GeoServiceAdapter()
    data = geo.get_location("8.8.8.8")

    claves_requeridas = {"lat", "lng", "city", "country"}
    assert set(data.keys()) == claves_requeridas, f"Claves incorrectas: {data.keys()}"
    assert isinstance(data["lat"],     float), "lat debe ser float"
    assert isinstance(data["lng"],     float), "lng debe ser float"
    assert isinstance(data["city"],    str),   "city debe ser str"
    assert isinstance(data["country"], str),   "country debe ser str"

    print(f"\n  ✓ Claves presentes : {sorted(data.keys())}")
    print(f"  ✓ Tipos correctos  : lat=float, lng=float, city=str, country=str\n")


# ─────────────────────────────────────────────────────────────────────────────
# TEST 4 — extensibilidad: tercer proveedor hipotético
# ─────────────────────────────────────────────────────────────────────────────

def test_extensibilidad_tercer_proveedor():
    """
    Si mañana llega FutureGeoProvider con otra API distinta,
    solo hay que crear FutureGeoAdapter(OldGeoService).
    Los 40 archivos del sistema no cambian en absoluto.
    """
    print("=" * 60)
    print("TEST 4 — Extensibilidad con un tercer proveedor hipotético")
    print("=" * 60)

    from geo_adapter import OldGeoService

    class FutureGeoProvider:
        """Tercer proveedor imaginario con otra API distinta."""
        def resolve(self, address: str) -> dict:
            return {"x": 10.0, "y": 20.0, "place": "Buenos Aires", "iso": "AR"}

    class FutureGeoAdapter(OldGeoService):
        def __init__(self):
            self._provider = FutureGeoProvider()

        def get_location(self, ip: str) -> dict:
            result = self._provider.resolve(ip)   # API completamente distinta
            return {
                "lat":     result["x"],
                "lng":     result["y"],
                "city":    result["place"],
                "country": result["iso"],
            }

    geo = FutureGeoAdapter()
    print("\n  Cambiando a FutureGeoProvider — 40 archivos intactos:")
    mostrar_info_ip(geo, "cualquier-ip")
    print()
    print("  ✓ Nuevo adapter creado en minutos.")
    print("  ✓ Cero cambios en el código cliente.\n")


# ─────────────────────────────────────────────────────────────────────────────
# Ejecutar
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    test_cliente_no_nota_el_cambio()
    test_adapter_es_old_geo_service()
    test_formato_respuesta_correcto()
    test_extensibilidad_tercer_proveedor()
    print("Todos los tests completados.")
