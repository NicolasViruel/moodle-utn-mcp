"""
Patrón Adapter — Geolocalización
==================================
Problema resuelto: el sistema tiene 40 archivos que usan OldGeoService.
El nuevo proveedor (NewGeoProvider) tiene una API distinta.
El GeoServiceAdapter traduce entre las dos sin tocar ninguna de las partes.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass


# ─────────────────────────────────────────────────────────────────────────────
# TARGET — la interfaz que todo el sistema ya conoce (NO SE TOCA)
# ─────────────────────────────────────────────────────────────────────────────

class OldGeoService(ABC):
    @abstractmethod
    def get_location(self, ip: str) -> dict:
        """
        Retorna: { 'lat': float, 'lng': float, 'city': str, 'country': str }
        """
        pass


# ─────────────────────────────────────────────────────────────────────────────
# ADAPTEE — el nuevo proveedor (NO SE TOCA)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Coordinates:
    latitude: float
    longitude: float

@dataclass
class Address:
    locality: str
    nation: str

@dataclass
class GeoResult:
    coordinates: Coordinates
    address: Address


class NewGeoProvider:
    """
    API del nuevo proveedor — estructura completamente distinta a OldGeoService.
    En producción esto vendría de una librería externa. No se modifica.
    """
    def locate(self, ip: str) -> GeoResult:
        # Simulación de respuesta del proveedor nuevo
        _mock_data = {
            "200.45.123.10": GeoResult(
                coordinates=Coordinates(latitude=-32.89, longitude=-68.83),
                address=Address(locality="Mendoza", nation="Argentina")
            ),
            "8.8.8.8": GeoResult(
                coordinates=Coordinates(latitude=37.42, longitude=-122.08),
                address=Address(locality="Mountain View", nation="United States")
            ),
        }
        if ip not in _mock_data:
            raise ValueError(f"IP no encontrada en el proveedor: {ip}")
        return _mock_data[ip]


# ─────────────────────────────────────────────────────────────────────────────
# ADAPTER — la única clase nueva
# ─────────────────────────────────────────────────────────────────────────────

class GeoServiceAdapter(OldGeoService):
    """
    Por fuera: se ve exactamente igual que OldGeoService.
    Por dentro: usa NewGeoProvider y traduce la respuesta.

    El sistema no nota el cambio. Si mañana llega un tercer proveedor,
    solo hay que crear un nuevo Adapter — los 40 archivos no se tocan.
    """

    def __init__(self):
        self._provider = NewGeoProvider()

    def get_location(self, ip: str) -> dict:
        result = self._provider.locate(ip)

        # Traducción: estructura nueva → formato viejo que espera el sistema
        return {
            "lat":     result.coordinates.latitude,
            "lng":     result.coordinates.longitude,
            "city":    result.address.locality,
            "country": result.address.nation,
        }
