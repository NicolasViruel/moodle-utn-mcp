"""
Tests del patrón Factory Method
================================
Cubre:
  1. Generar reportes en todos los formatos disponibles
  2. ReportService no instancia ninguna clase concreta directamente
  3. Agregar un formato nuevo sin tocar ReportService
  4. Error claro cuando el formato no existe
"""

from report_factory import ReportFactory, ReportService, Report


DATOS_EJEMPLO = [
    "Producto A - $1.200",
    "Producto B - $3.450",
    "Producto C - $890",
]


# ─────────────────────────────────────────────────────────────────────────────
# TEST 1 — generar reportes en todos los formatos
# ─────────────────────────────────────────────────────────────────────────────

def test_todos_los_formatos():
    print("=" * 60)
    print("TEST 1 — Generar reporte en cada formato disponible")
    print("=" * 60)

    servicio = ReportService()

    for formato in ["pdf", "excel", "csv", "html"]:
        print(f"\n  ── Formato: {formato.upper()} ──")
        output = servicio.generate(DATOS_EJEMPLO, formato)
        print(output)


# ─────────────────────────────────────────────────────────────────────────────
# TEST 2 — ReportService nunca instancia clases concretas
# ─────────────────────────────────────────────────────────────────────────────

def test_service_no_conoce_concretos():
    print("\n" + "=" * 60)
    print("TEST 2 — ReportService trabaja solo con la interfaz Report")
    print("=" * 60)

    servicio = ReportService()
    output   = servicio.generate(DATOS_EJEMPLO, "pdf")
    report   = ReportFactory.create("pdf")

    assert isinstance(report, Report), "La fábrica debe retornar un Report"
    assert len(output) > 0,            "El reporte no debe estar vacío"

    print("\n  ✓ ReportFactory.create() retorna un Report (no una clase concreta)")
    print("  ✓ ReportService solo llama a .set_data(), .add_header(), .render(), .get_output()")
    print("  ✓ ReportService no importa PDFReport, ExcelReport ni ninguna clase concreta\n")


# ─────────────────────────────────────────────────────────────────────────────
# TEST 3 — agregar formato nuevo (MarkdownReport) sin tocar ReportService
# ─────────────────────────────────────────────────────────────────────────────

def test_nuevo_formato_sin_tocar_servicio():
    print("=" * 60)
    print("TEST 3 — Nuevo formato Markdown sin tocar ReportService")
    print("=" * 60)

    from report_factory import Report

    class MarkdownReport(Report):
        """Nuevo formato — zero cambios en ReportService ni en formatos existentes."""
        def render(self) -> None:
            rows = "\n".join(f"- {row}" for row in (self._data or []))
            self._content = (
                f"# {self._header}\n\n"
                f"{rows}\n\n"
                f"---\n_{self._footer}_"
            )

        def get_output(self) -> str:
            return self._content

    # Registrar el nuevo formato en la fábrica
    ReportFactory.register("markdown", MarkdownReport)

    # Usar el servicio con el nuevo formato — no se tocó nada del servicio
    servicio = ReportService()
    output   = servicio.generate(DATOS_EJEMPLO, "markdown")

    print("\n  ── Formato: MARKDOWN ──")
    print(output)
    print("\n  ✓ MarkdownReport creado y registrado sin modificar ReportService\n")


# ─────────────────────────────────────────────────────────────────────────────
# TEST 4 — error claro con formato desconocido
# ─────────────────────────────────────────────────────────────────────────────

def test_formato_desconocido_lanza_error():
    print("=" * 60)
    print("TEST 4 — Formato desconocido lanza ValueError descriptivo")
    print("=" * 60)

    servicio = ReportService()
    try:
        servicio.generate(DATOS_EJEMPLO, "docx")
        print("  ✗ Debería haber lanzado ValueError")
    except ValueError as e:
        print(f"\n  ✓ ValueError capturado correctamente:")
        print(f"    → {e}\n")


# ─────────────────────────────────────────────────────────────────────────────
# Ejecutar
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    test_todos_los_formatos()
    test_service_no_conoce_concretos()
    test_nuevo_formato_sin_tocar_servicio()
    test_formato_desconocido_lanza_error()
    print("Todos los tests completados.")
