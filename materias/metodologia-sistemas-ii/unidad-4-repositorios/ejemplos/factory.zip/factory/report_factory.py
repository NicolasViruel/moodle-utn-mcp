"""
Patrón Factory Method — Sistema de reportes
=============================================
Problema resuelto: la lógica de construcción (qué clase crear) está separada
de la lógica de uso (cómo trabajar con el reporte).
ReportService no importa ni instancia ninguna clase concreta de reporte.
"""

from abc import ABC, abstractmethod
from datetime import date


# ─────────────────────────────────────────────────────────────────────────────
# PRODUCTO — interfaz que todos los reportes deben cumplir
# ─────────────────────────────────────────────────────────────────────────────

class Report(ABC):
    def __init__(self):
        self._data    = None
        self._header  = ""
        self._footer  = ""
        self._content = ""

    def set_data(self, data) -> None:
        self._data = data

    def add_header(self, text: str) -> None:
        self._header = text

    def add_footer(self, text: str) -> None:
        self._footer = text

    @abstractmethod
    def render(self) -> None:
        """Genera el contenido interno del reporte."""
        pass

    @abstractmethod
    def get_output(self) -> str:
        """Retorna el reporte listo para usar."""
        pass


# ─────────────────────────────────────────────────────────────────────────────
# PRODUCTOS CONCRETOS
# ─────────────────────────────────────────────────────────────────────────────

class PDFReport(Report):
    def render(self) -> None:
        rows = "\n".join(f"  | {row}" for row in (self._data or []))
        self._content = (
            f"[PDF] ╔══════════════════════════════╗\n"
            f"[PDF] ║  {self._header:<28}║\n"
            f"[PDF] ╠══════════════════════════════╣\n"
            f"{rows}\n"
            f"[PDF] ╠══════════════════════════════╣\n"
            f"[PDF] ║  {self._footer:<28}║\n"
            f"[PDF] ╚══════════════════════════════╝"
        )

    def get_output(self) -> str:
        return self._content


class ExcelReport(Report):
    def render(self) -> None:
        header_row = "Columna A\tColumna B\tColumna C"
        rows = "\n".join(f"[XLS] {row}" for row in (self._data or []))
        self._content = (
            f"[XLS] >> {self._header}\n"
            f"[XLS] {header_row}\n"
            f"{rows}\n"
            f"[XLS] -- {self._footer}"
        )

    def get_output(self) -> str:
        return self._content


class CSVReport(Report):
    def render(self) -> None:
        rows = "\n".join(str(row) for row in (self._data or []))
        self._content = (
            f"# {self._header}\n"
            f"{rows}\n"
            f"# {self._footer}"
        )

    def get_output(self) -> str:
        return self._content


class HTMLReport(Report):
    """
    Formato nuevo agregado sin tocar ReportService ni ningún reporte existente.
    Solo hay que crear esta clase y agregar una línea en ReportFactory.
    """
    def render(self) -> None:
        rows = "\n".join(f"  <li>{row}</li>" for row in (self._data or []))
        self._content = (
            f"<html>\n"
            f"  <h1>{self._header}</h1>\n"
            f"  <ul>\n{rows}\n  </ul>\n"
            f"  <footer>{self._footer}</footer>\n"
            f"</html>"
        )

    def get_output(self) -> str:
        return self._content


# ─────────────────────────────────────────────────────────────────────────────
# FACTORY — toda la decisión de construcción vive acá
# ─────────────────────────────────────────────────────────────────────────────

class ReportFactory:
    """
    Por qué Factory Method y no Abstract Factory:
    Abstract Factory se usa cuando hay FAMILIAS de objetos relacionados
    que deben crearse juntos (ej: botón + input + checkbox del mismo tema visual).
    Acá solo hay un tipo de objeto (Report) en distintas variantes de formato.
    Factory Method es suficiente y más simple para este caso.
    """

    _registry: dict[str, type] = {
        "pdf":   PDFReport,
        "excel": ExcelReport,
        "csv":   CSVReport,
        "html":  HTMLReport,
    }

    @classmethod
    def create(cls, format_type: str) -> Report:
        report_class = cls._registry.get(format_type.lower())
        if report_class is None:
            available = ", ".join(cls._registry.keys())
            raise ValueError(
                f"Formato '{format_type}' no soportado. "
                f"Disponibles: {available}"
            )
        return report_class()

    @classmethod
    def register(cls, format_type: str, report_class: type) -> None:
        """
        Permite registrar formatos nuevos en runtime sin modificar la fábrica.
        Útil para plugins o extensiones externas.
        """
        cls._registry[format_type.lower()] = report_class


# ─────────────────────────────────────────────────────────────────────────────
# SERVICIO — agnóstico al formato, nunca instancia clases concretas
# ─────────────────────────────────────────────────────────────────────────────

class ReportService:
    def generate(self, data: list, format_type: str) -> str:
        report = ReportFactory.create(format_type)   # no sabe qué tipo concreto es
        report.set_data(data)
        report.add_header("Reporte Mensual")
        report.add_footer(f"Generado el {date.today()}")
        report.render()
        return report.get_output()
